# Program to calc concrete cover

### DEFINE FUNCTION ###
def concrete_cover(rebar_diam, Structural__lifetime__class, Exposure_class):
    #deviator cover
    dev_cover = 10 
    rebar_diam = 25
    Structural__lifetime__class = "S4"
    Exposure_class = "XC4"
    ### DURABILITY COVER ###
    # set up lists (like a 1d matrix)(list alsways have []) - going to use embedded lists  to make a multi dimensional matrix
    Structural__lifetime__class_list = ["S1", "S2", "S3", "S4", "S5", "S6"]
    Exposure_class_list = ["X0", "XC1", "XC2", "XC3", "XC4", "XD1", "XS1", "XD2", "XS2", "XD3", "XS3"]
    #Table written in same format as source (encvironmental requirement for Cmin,dur)
    Cdur_Cover_thickness_table = [
        [10, 10, 10, 10, 15, 20, 20, 25, 25, 30, 30],
        [10, 10, 15, 15, 20, 25, 25, 30, 30, 35, 35],
        [10, 10, 20, 20, 25, 30, 30, 35, 35, 40, 40],
        [10, 15, 25, 25, 30, 35, 35, 40, 40, 45, 45],
        [15, 29, 30, 30, 35, 40, 40, 45, 45, 50, 50],
        [20, 25, 35, 35, 40, 45, 45, 50, 50, 55, 55]]

    #search list
    #row and column gives position of value (relating the heading lists to the table data)
    #index gives position ...
    row = Structural__lifetime__class_list.index(Structural__lifetime__class)
    column = Exposure_class_list.index(Exposure_class)

    Cdur_cover_thickness = Cdur_Cover_thickness_table[row][column]
    #^pulling from matrix list row first, then column

    ##calculating nominal cover
    rebar_cover = rebar_diam
    minimum_cover = max(rebar_cover, Cdur_cover_thickness, 10)
    Cover_Nominal = dev_cover + minimum_cover

# return gives back the result of function (print simply displays in terminal - it wouldnt work here)
    return Cover_Nominal

foo = concrete_cover(10,"S3","XC4")
print(foo)

# Bending for beam
# Import math Library
import math
from math import *
Md= 1236176930 #Momemts of beam (Nmm)
h = 836 #height of x-section(mm)
b = 600 #width of x-section(mm)
c = 40 #nominal cover(mm)*
Ac = b*h #Area of x-section
Fck = 30 #concrete strength (MPa)
Fyk = 500 #Characteristic strength of steel (MPa)
Fyd = 435 #yield strength of steal with a partil safety factor of 1.15
Fctm =  2.9 #
percentredist = 15 #% redistribution
redist_ratio = 0.85 #redistribution ratio
k_prime = 0.168 #k' from table 
dt = 25 #diameter of reinforcement in tension (mm)
dc = 15 #diameter of reinforcement in compression (mm)
ds = 8 #diameter of shear links
d = h - c-(dt/2)- ds  #depth between top of x-section and middle of reinforcement diameter, effective depth
d2 = c + (dc/2) + ds  #Effective depth for compression
k = Md/(b*(d**2)*Fck) # Flexural rigidity
#
if k <= k_prime:
    z = (d/2)*(1+(1-sqrt(3.53*k))) # Lever arm
    if z <= 0.95*d:
        As = Md/(Fyd*z)   # tension reinforcement
        As_min = (0.26*Fctm*b*d)/Fyk # Minimum reinforcement requirement
        if As < As_min:   # minimum reinforcement
            print("More reinforecement needed")     
        else:
            As_max = 0.04*Ac  # Max reinforcement
            if As_max < As:
                print("Too much reinforcement")
    ##Tension reinforcement
    rebar_area_t = (math.pi*(dt**2))/4    # area of rebar for tension member
    num_bars_t = math.ceil((As/rebar_area_t))   # number of bars
    total_area_t  = num_bars_t*rebar_area_t      # total area included in cross-section
    print(total_area_t)
            
    
else:
    z = (d/2)*(1+(1-sqrt(3.53*k_prime)))
    x = (2*(d-z))/0.8
    Fsc = 700*((x-d2)/x) 
    if Fsc <= Fyd:
        As2 = (k-k_prime)*Fck*b*(d**2)/(Fsc*(d-d2))
        As = ((k_prime*Fck*b*(d**2))/(Fyd*z))+((As2*Fsc)/Fyd)
        As_max = 0.04*Ac
        if As_max < As:
            print("Too much reinforcement")
        else:
            print("")
    #Compression reinforcement

    rebar_area_c = (math.pi*(dc**2))/4    # area of rebar for tension member
    num_bars_c = math.ceil((As2/rebar_area_c))
    total_area_c  = num_bars_c*rebar_area_c     # total area included in cross-section
    print(total_area_c)

    ##Tension reinforcement
    rebar_area_t = (math.pi*(dt**2))/4    # area of rebar for tension member
    num_bars_t = math.ceil((As/rebar_area_t))
    total_area_t  = num_bars_t*rebar_area_t      # total area included in cross-section
    print(num_bars_c)

# Bending for beam
# Import math Library
import math
from math import *
Md= 971971100 #Momemts of beam (Nmm)
h = 836 #height of x-section(mm)
b = 600 #width of x-section(mm)
c = 40 #nominal cover(mm)*
Ac = b*h #Area of x-section
Fck = 30 #concrete strength (MPa)
Fyk = 500 #Characteristic strength of steel (MPa)
Fyd = 435 #yield strength of steal with a partil safety factor of 1.15
Fctm =  2.9 #
percentredist = 15 #% redistribution
redist_ratio = 0.85 #redistribution ratio
k_prime = 0.168 #k' from table 
dt = 25 #diameter of reinforcement in tension (mm)
dc = 15 #diameter of reinforcement in compression (mm)
ds = 8 #diameter of shear links
d = h - c-(dt/2)- ds #depth between top of x-section and middle of reinforcement diameter, effective depth
d2 = c + (dc/2) + ds #
k = Md/(b*(d**2)*Fck)#
#
if k <= k_prime:
    z = (d/2)*(1+(1-sqrt(3.53*k)))
    if z <= 0.95*d:
        As = Md/(Fyd*z)   # tension reinforcement
        As_min = (0.26*Fctm*b*d)/Fyk # Minimum reinforcement requirement
        if As < As_min:   # minimum reinforcement
            print("More reinforecement needed")     
        else:
            As_max = 0.04*Ac  # Max reinforcement
            if As_max < As:
                print("Too much reinforcement")
    ##Tension reinforcement
    rebar_area_t = (math.pi*(dt**2))/4    # area of rebar for tension member
    num_bars_t = math.ceil((As/rebar_area_t))   # number of bars
    total_area_t  = num_bars_t*rebar_area_t      # total area included in cross-section
    print(total_area_t)
    print(num_bars_t)
            
    
else:
    z = (d/2)*(1+(1-sqrt(3.53*k_prime)))
    x = (2*(d-z))/0.8
    Fsc = 700*((x-d2)/x) 
    if Fsc <= Fyd:
        As2 = (k-k_prime)*Fck*b*(d**2)/(Fsc*(d-d2))
        As = ((k_prime*Fck*b*(d**2))/(Fyd*z))+((As2*Fsc)/Fyd)
        As_max = 0.04*Ac
        if As_max < As:
            print("Too much reinforcement")
        else:
            print("")
    #Compression reinforcement

    rebar_area_c = (math.pi*(dc**2))/4    # area of rebar for tension member
    num_bars_c = round((As2/rebar_area_c),1)
    total_area_c  = num_bars_c*rebar_area_c     # total area included in cross-section
    print(total_area_c)

    ##Tension reinforcement
    rebar_area_t = (math.pi*(dt**2))/4    # area of rebar for tension member
    num_bars_t = round((As/rebar_area_t),1)
    total_area_t  = num_bars_t*rebar_area_t      # total area included in cross-section
    print(num_bars_c)
##    
##
#Calculating shear resistance of beam
ds = 8
bw = b #width of beam mm
d_effec = h-c-(dt/2)-ds #effective depth, mm
As1 = total_area_t #area of tensile reinforcement, mm^2
Ved0 = 798908 #applied shear, N
Vedd = 739977.08 #applied shear at effective depth, N

#calculate concrte shear capacity
K = (1+(sqrt(200/d_effec)))
Rho1 = As1/(bw*d_effec)
Vrdc = (0.12*K*(100*Rho1*Fck)**(1/3))*bw*d_effec
print(Vrdc)

#minimum shear reinforcement
Asw_smin =  (0.08*sqrt(Fck)*bw)/Fyk

if Vrdc > Ved0:
    Asw_s = Asw_smin  #minimum shear reinforcement required
else:
    VED0 = Ved0 / (0.9 * bw * d_effec)  # shear stress from shear force at the support
    tfck = [20, 25, 28, 30, 32, 35, 40, 45, 50]
    tvrd22 = [2.54, 3.10, 3.43, 3.64, 3.84, 4.15, 4.63, 5.08, 5.51]
    tvrd45 = [3.68, 4.50, 4.97, 5.28, 5.58, 6.02, 6.72, 7.38, 8.00]

    id = tfck.index(Fck)  # index of concrete class

    # check the concrete strut capacity
    if VED0 < tvrd22[id]:  # angle less than 22
        cot_t = 2.5
        VEDD = Vedd / (0.9 * bw * d_effec)
        Asw_s = (VEDD * bw) / (Fyk * cot_t)  # area of reinforcement per mm
    elif VED0 < tvrd45[id]:  # angle less than 45
        theta = 0.5 * (asin(VED0 / (0.2 * Fck * (1 - (Fck / 250)))))
        cot_t = 1 / tan(theta)
        VEDD = Vedd / (0.9 * bw * d_effec)
        Asw_s = (VEDD * bw) / (Fyd * cot_t) # area of reinforcement per mm
    else:
        print("Redesign section")
    sl_max = min(0.75*d_effec,600) #maximum spacing for vertical shear reinforcement

# using 3 shear links, 3H8@17.5c/c


##  
####
#Bending for slab
from math import *
Md = 164886000 #Momemts of beam (Nmm)
h = 296 #height of x-section(mm)
b = 1000 #width of x-section(mm)
c = 40 #nominal cover(mm)*
Ac = b*h #Area of x-section
Fck = 30 #concrete strength (MPa)
Fyk = 500 #Characteristic strength of stell (MPa)
Fyd = Fyk/1.15 #yield strength of steal with a partil safety factor of 1.15
Fctm =  2.9 #
percentredist = 15 #% redistribution
redist_ratio = 0.85 #redistribution ratio
k_prime = 0.163 #k' from table 
dt = 25 #diameter of reinforcement in tension (mm)
dc = 15 #diameter of reinforcement in compression (mm)
ds = 8 #diameter of shear links
d = h - c-(dt/2) - ds #depth between top of x-section and middle of reinforcement diameter
d2 = c + (dc/2) + ds 
k = Md/(b*(d**2)*Fck)
print(k)
#
if k <= k_prime:
    z = (d/2)*(1+(1-sqrt(3.53*k)))
    print(z)
    if z <= 0.95*d:
        As = Md/(Fyd*z)   # tension reinforcement
        As_min = (0.26*Fctm*b*d)/Fyk # Minimum reinforcement requirement
        if As < As_min:   # minimum reinforcement
            print("More reinforecement needed")     
        else:
            As_max = 0.04*Ac  # Max reinforcement
            if As_max < As:
                print("Too much reinforcement")
    else:
        print("value is too small")

#Tension reinforcement

rebar_area = (math.pi*(dt**2))/4    # area of rebar for tension member
num_bars = math.ceil((As/rebar_area))
total_area  = num_bars*rebar_area      # total area included in cross-section
print(num_bars)
print(rebar_area)
print(total_area)
##
##
#Bending for slab
from math import *
Md = 92515000 #Momemts of beam (Nmm)
h = 296 #height of x-section(mm)
b = 1000 #width of x-section(mm)
c = 40 #nominal cover(mm)*
Ac = b*h #Area of x-section
Fck = 30 #concrete strength (MPa)
Fyk = 500 #Characteristic strength of stell (MPa)
Fyd = Fyk/1.15 #yield strength of steal with a partil safety factor of 1.15
Fctm =  2.9 #
percentredist = 15 #% redistribution
redist_ratio = 0.85 #redistribution ratio
k_prime = 0.163 #k' from table 
dt = 25 #diameter of reinforcement in tension (mm)
dc = 15 #diameter of reinforcement in compression (mm)
ds = 8 #diameter of shear links
d = h - c-(dt/2) - ds #depth between top of x-section and middle of reinforcement diameter
d2 = c + (dc/2) + ds #
k = Md/(b*(d**2)*Fck)#
print(k)
if k <= k_prime:
    z = (d/2)*(1+(1-sqrt(3.53*k)))
    print(z)
    if z <= 0.95*d:
        As = Md/(Fyd*z)   # tension reinforcement
        As_min = (0.26*Fctm*b*d)/Fyk # Minimum reinforcement requirement
        if As < As_min:   # minimum reinforcement
            print("More reinforecement needed")     
        else:
            As_max = 0.04*Ac  # Max reinforcement
            if As_max < As:
                print("Too much reinforcement")
    else:
        print("value is too small")
#Tension reinforcement

rebar_area = (math.pi*(dt**2))/4    # area of rebar for tension member
num_bars = math.ceil((As/rebar_area))
total_area  = num_bars*rebar_area      # total area included in cross-section
print(num_bars)
print(rebar_area)
print(total_area)

    
##
##
#Column classification
##l = 4 # Height of column (m)
##I = (b*(h**3))/12  # second moment of area
##Ac_column = 360000 # Area of concrete column (mm^2)
##Med = 60893600
##Ned = 8064271  # Normal stress
##Fcd = 40 # concrete compressive strength (mPa)

from scipy.optimize import fsolve


def equations(p):
   x,A_s = p
   #input data
   Med = 659.0227e6
   Ned = 500.8936e3  # Normal stress
   Fcd = 40 # concrete compressive strength (mPa)
   b_col = 600 # width of column x-section (mm)
   h_col = 600 # Height of column (mm)
   d2 = 542
   d2_2 = h_col-d2
   eyd = 2.17e-3 # yield design strain
   Es = 200e3 # Young's modulus (mPa,megapascal)
   eu = 3.5e-3 # ultimate strian
   s = 0.8*x
   if s > h_col:
     s= h
   if x < 0.617*d2:
     #tension failure
     fs = 0.87*Fyk
     esc = eu*(x-d2_2)/x
     if esc < -eyd:
       fsc = -0.87*Fyk
     elif esc > eyd:
       fsc = 0.87*Fyk
     else:
       fsc = esc*Es
   elif x > 0.87*Fyk:
      #'Compression failure
      fsc = 0.87*Fyk
      es = eu*(d2-x)/x
      if es < -eyd:
        fs = -0.87*Fyk
      elif es > eyd:
        fs = 0.87*Fyk
      else:
        fs = es*Es

   return (Ned/(b_col*h_col*Fck)-0.567*s/h-A_s/(2*b_col*h_col)*(fsc-fs)/Fck,
           Med/(b_col*h_col**2*Fck)-0.567*s/(h**2)*(h_col-s)/2- A_s/(2*Fck*b_col*h_col**2)*(d2-h_col/2)*(fsc+fs))
x,A_s = fsolve(equations, (50,100))
print(x, A_s)
num_bars_c = A_s/ ((math.pi*20**2)/4)
print(num_bars_c)




#Foundations
bc = 600 # width of column
hc = 600 # height of column
u_0 = 2400 # perimeter of column
qk= 0.7 # bearing pressure of soil (n/mm^2)
M = 537925400 # moment acting on the base (N) 
p = 2567893.86  # total pressure
L = math.ceil(p/qk)**0.5 # width of base
e = M/p # eccentricity
gamma_c = 1.5 
alph_ct = 0.6
sigma_gd = 0.42
fctk = 2 #Chraracteristic tensile strength of concrete
fctd = (alpha_ct*fctk)/gamma_c # design tensile strength of concrete
if e <= L/6:
  sigma_left = (p/L)*(1+((6*e)/L)) # Ask about 1/b
else :
  sigma_left = (2*p)/((1.5*L)-(3*e))
# Check to see if pressure exceeds allowable pressure
if sigma_left <= qk:
  a = (L-bc)/2 # width either side of column
  hf = (a/0.85)*sqrt((9*sigma_gd)/fctd) # height of foundation (mm)
  df = 542 # height of reinforcement (mm)
  # check if reinforcement is needed
  if hf >= ((a/0.85)*(sqrt((9*sigma_gd)/fctd))):
    #Calculate bearing pressure for design reinforcement
    pd = p  # (N)
    sigma_cd = (pd/(L-2*e)) # design stress (Ask about 1/b)
    m_ed = 0.5 * L * a^2 * sigma_cd
    K_f = m_ed/(L*d^2*Fck)
    if K_f < k_prime :
      z_f = (df/2)*(1+sqrt(1-(3.53*K_f)))
      As_f = m_ed/(0.87*Fyk*z_f)
      # Check for punching shear at th face of column
      v1 = 0.6*((1-Fck)/250)
      Vrd_m = 0.5*v1*(Fck/1.5)
      ved = pd
      delta_ved = bc*hc*sigma_cd
      ved_max = (1*(ved-delta_ved))/(u_0*df)
##      if ved_max < Vrd_m :
##        # check for punching shear at control perimeter
##        u_1 = (u_0+(2*pi()*(2*df)^2)) # critical perimeter (mm)
##        delta_VED = ((hc*bc)+(4*2*df*400)+(pi()*(2*550)^2))*sigma_cd
##        ved_crit = (vd-delta_VED)/(u_1*df) # Ask about df = deff
##        k_F =
##        1=sqrt(200/df)
##        Pl = = sqrt(plz*Ply)
##        Vrd_c = 0.12*k_F*(100*Pl*Fck)^1/3
##        if Vrd_c >= (0.035*(k_F^3/2)*Fck^1/2) && ved_crit < Vrd_c:
##          Ved_crit = ((a-df)*sigma_cd)/df


